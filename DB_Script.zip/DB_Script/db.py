import cx_Oracle

#connection = oracledb.connect(user='SYSDBA', password='12345',  host="localhost", port=1521, service_name="xe")

# connection = cx_Oracle.connect(
#     user='SYSDBA',
#     password='12345',
#     dsn=cx_Oracle.makedsn("localhost",1521,"xe")
# )

connection = cx_Oracle.connect('system/12345@localhost:1521/xe')
print(connection.version)

cursor=connection.cursor()

cursor.execute('SELECT COUNT(*) FROM students')
#rows = cursor.fetchall()
count = cursor.fetchone()[0]

print(count)
 
   

