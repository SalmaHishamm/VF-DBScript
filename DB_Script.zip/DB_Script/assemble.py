
import cx_Oracle
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr #3ashan yaban salma hisham msh el mail

alarm_count=3

connection = cx_Oracle.connect('system/12345@localhost:1521/xe')

cursor=connection.cursor()

cursor.execute('SELECT COUNT(*) FROM students')
#rows = cursor.fetchall()
count = cursor.fetchone()[0]
print(count)

# Sender's email address and password
sender_email = "salmahesham60@gmail.com"
sender_name="Salma Hisham"
password = "rjnkzyokivtspvxt"

# Recipient's email address
recipient_email = ["salmahesham60@gmail.com","abdelrahmanharoun99@gmail.com"]

# Create the email message
subject = "The system status is in danger!"

text = 'Hello this mail sent from python'

html = """\
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warning</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f8e1e1;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .warning-container {
            background-color: #f44336;
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 30px;
        }
        p {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="warning-container">
        <h1>Warning!</h1>
       
        <p>The number of records has exceeded the limit</p>
    </div>
</body>
</html>
"""

msg = MIMEMultipart("alternative") #alternative de khalteny html file maykonsh attachment
#msg['From'] = sender_email
msg['From'] = formataddr((sender_name,sender_email))
msg['To'] = ', '.join(recipient_email)
msg['Subject'] = subject

part1=MIMEText(text, 'plain')
part2=MIMEText(html, 'html')

msg.attach(part1)
msg.attach(part2)




# Connect to the SMTP server and send the email
smtp_server = "smtp.gmail.com"  # Replace with your SMTP server address
smtp_port = 587  # Replace with your SMTP server port (usually 587 for TLS)


if (count>=alarm_count):
 try :
  with smtplib.SMTP(smtp_server, smtp_port) as server:
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, recipient_email, msg.as_string())

 except Exception as e:
    print(e)
    
else :
    print("The status is safe")
    
    
    




   
