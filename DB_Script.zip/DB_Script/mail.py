import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr #3ashan yaban salma hisham msh el mail

# Sender's email address and password
sender_email = "salmahesham60@gmail.com"
sender_name="Salma Hisham"
password = "rjnkzyokivtspvxt"

# Recipient's email address
recipient_email = ["salmahesham60@gmail.com","abdelrahmanharoun99@gmail.com"]

# Create the email message
subject = "Subject of the Email"

text = 'Hello this mail sent from python'

html = """\
<html>
  <body>
    <p>Hi,<br>
       How are you?<br>
       <a href="http://www.realpython.com">Real Python</a>
       has many great tutorials.
    </p>
  </body>
</html>
"""

msg = MIMEMultipart("alternative") #alternative de khalteny html file maykonsh attachment
#msg['From'] = sender_email
msg['From'] = formataddr((sender_name,sender_email))
msg['To'] = ', '.join(recipient_email)
msg['Subject'] = subject

part1=MIMEText(text, 'plain')
part2=MIMEText(html, 'html')


msg.attach(part2)
msg.attach(part1)



# Connect to the SMTP server and send the email
smtp_server = "smtp.gmail.com"  # Replace with your SMTP server address
smtp_port = 587  # Replace with your SMTP server port (usually 587 for TLS)

# n=len(recipient_email)
i=0

#while i < n:
try :
  with smtplib.SMTP(smtp_server, smtp_port) as server:
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, recipient_email, msg.as_string())

except Exception as e:
    print(e)